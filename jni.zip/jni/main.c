#include "glimmerAl.h"


REGISTER_STANDARD* beginRegister1(){
        return beginRegister();
}



    
