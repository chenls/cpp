#include "cfp_memory.h"
#ifdef CFP_ENV_TEE_QSEE
#include "qsee_heap.h"
#elif defined (CFP_ENV_TEE_PINGBO) || defined CFP_ENV_TEE_DOUJIA || defined CFP_ENV_TEE_TRUSTY
#include <stdlib.h>
#include <string.h>
#endif


void *cfp_malloc(size_t size)
{
#ifdef CFP_ENV_TEE_QSEE
	return qsee_malloc(size);
#else
	return malloc(size);
#endif
}

void *cfp_calloc(size_t num, size_t size)
{
#ifdef CFP_ENV_TEE_QSEE
	return qsee_calloc(num, size);
#else
	return calloc(num, size);
#endif
}

void *cfp_realloc(void *ptr, size_t new_size)
{
#ifdef CFP_ENV_TEE_QSEE
	return qsee_realloc(ptr, new_size);
#else
	return realloc(ptr, new_size);
#endif
}

void cfp_free(void *buffer)
{
#ifdef CFP_ENV_TEE_QSEE
	return qsee_free(buffer);
#else
	free(buffer);
	return;
#endif
}

int cfp_memcmp(const void *s1, const void *s2, size_t n)
{
	return memcmp(s1, s2, n);
}
void *cfp_memcpy(void *dest, const void *src, size_t n)
{
	return memcpy(dest, src, n);
}

void *cfp_memset(void *s, int c, size_t n)
{
	return memset(s, c, n);
}
