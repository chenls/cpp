#ifndef __CFP_MEMORY__
#define __CFP_MEMORY__

#include <stddef.h>

void *cfp_malloc(size_t size);
void *cfp_calloc(size_t num, size_t size);
void *cfp_realloc(void *buffer, size_t new_size);
void cfp_free(void *buffer);

#endif
